---
layout: home
title: Jekyll Atlantic Theme
heading: <em>Jekyll Tailwind</em> Starter Blog
description: Atlantic is a beautiful Tailwind CSS theme for Jekyll. It shows best practices for using Tailwind with Jekyll.

---
